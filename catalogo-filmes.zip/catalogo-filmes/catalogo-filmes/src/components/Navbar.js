import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';

function Navbar() {
  return (
    <nav className={styles.navbar}>
      <Link to="/">Home</Link>
      <Link to="/catalogo">Catálogo</Link>
      <Link to="/sobre">Sobre</Link>
    </nav>
  );
}

export default Navbar;
