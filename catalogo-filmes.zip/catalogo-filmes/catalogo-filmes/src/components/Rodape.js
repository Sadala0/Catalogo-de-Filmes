import styles from './Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.rodape}>
      <p>Catálogo de Filmes - Trabalho de Desenvolvimento Web</p>
    </footer>
  );
}

export default Rodape;
