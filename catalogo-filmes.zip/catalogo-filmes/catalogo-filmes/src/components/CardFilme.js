import styles from './CardFilme.module.css';

function CardFilme({ imagem, titulo, categoria, descricao }) {
  return (
    <div className={styles.card}>
      <img src={imagem} alt={titulo} className={styles.imagem} />
      <h3>{titulo}</h3>
      <p>{categoria}</p>
      <p>{descricao}</p>
    </div>
  );
}

export default CardFilme;
