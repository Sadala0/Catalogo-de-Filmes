import CardFilme from '../components/CardFilme';
import styles from './Catalogo.module.css';
import foto1 from '../images/acao.jpg';
import foto2 from '../images/comedia.jpg';
import foto3 from '../images/terror.jpg';

function Catalogo() {
  return (
    <div className={styles.catalogo}>
      <CardFilme
        imagem={foto1}
        titulo="Veloses e Furiosos"
        categoria="Ação"
        descricao="Corridas de rua ilegais, assaltos cinematográficos e fortes laços de lealdade entre família."
      />
      <CardFilme
        imagem={foto2}
        titulo="O Alto da Compadecida"
        categoria="Comédia"
        descricao="João Grilo e Chicó, dois sertanejos pobres que usam a esperteza para sobreviver às dificuldades de Taperoá"
      />
      <CardFilme
        imagem={foto3}
        titulo="Corra!"
        categoria="Terror"
        descricao="Um jovem fotógrafo, viaja para passar o fim de semana na propriedade rural da família de sua namorada"
      />
    </div>
  );
}

export default Catalogo;
