function Home() {
  return (
    <div>
      <h1>Bem-vindo ao Catálogo de Filmes</h1>
      <p>Veja os filmes na página Catálogo.</p>
    </div>
  );
}

export default Home;
