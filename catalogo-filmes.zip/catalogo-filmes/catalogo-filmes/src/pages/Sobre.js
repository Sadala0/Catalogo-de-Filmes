function Sobre() {
  return (
    <div>
      <h1>Sobre</h1>
      <p>Site feito com React para a aula de Desenvolvimento Web.</p>
    </div>
  );
}

export default Sobre;
